import React from 'react';
import './Home.css'; // Create this file for additional styles

const Home = () => {
  return (
    <div className="home-container">
    
   
    </div>
  );
};

export default Home;